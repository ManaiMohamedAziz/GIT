import { Component } from '@angular/core';

@Component({
  selector: 'app-index-four',
  templateUrl: './index-four.component.html',
  styleUrls: ['./index-four.component.scss']
})
export class IndexFourComponent {

}
