import { Component } from '@angular/core';

@Component({
  selector: 'app-index-six',
  templateUrl: './index-six.component.html',
  styleUrls: ['./index-six.component.scss']
})
export class IndexSixComponent {

}
