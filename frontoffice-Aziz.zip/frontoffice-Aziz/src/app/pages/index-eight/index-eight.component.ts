import { Component } from '@angular/core';

@Component({
  selector: 'app-index-eight',
  templateUrl: './index-eight.component.html',
  styleUrls: ['./index-eight.component.scss']
})
export class IndexEightComponent {

}
