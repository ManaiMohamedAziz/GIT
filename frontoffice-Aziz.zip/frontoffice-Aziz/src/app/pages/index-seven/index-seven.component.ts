import { Component } from '@angular/core';

@Component({
  selector: 'app-index-seven',
  templateUrl: './index-seven.component.html',
  styleUrls: ['./index-seven.component.scss']
})
export class IndexSevenComponent {

}
