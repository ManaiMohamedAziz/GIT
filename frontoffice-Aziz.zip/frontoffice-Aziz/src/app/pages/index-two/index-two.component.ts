import { Component } from '@angular/core';

@Component({
  selector: 'app-index-two',
  templateUrl: './index-two.component.html',
  styleUrls: ['./index-two.component.scss']
})
export class IndexTwoComponent {

}
