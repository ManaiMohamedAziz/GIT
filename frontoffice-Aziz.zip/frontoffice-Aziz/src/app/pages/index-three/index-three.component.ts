import { Component } from '@angular/core';

@Component({
  selector: 'app-index-three',
  templateUrl: './index-three.component.html',
  styleUrls: ['./index-three.component.scss']
})
export class IndexThreeComponent {

}
