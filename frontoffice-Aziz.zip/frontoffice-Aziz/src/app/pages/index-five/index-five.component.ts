import { Component } from '@angular/core';

@Component({
  selector: 'app-index-five',
  templateUrl: './index-five.component.html',
  styleUrls: ['./index-five.component.scss']
})
export class IndexFiveComponent {

}
